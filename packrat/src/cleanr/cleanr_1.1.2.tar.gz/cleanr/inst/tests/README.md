R CMD check only checks for files ending on .R, files ending on .r will be
ignored.

